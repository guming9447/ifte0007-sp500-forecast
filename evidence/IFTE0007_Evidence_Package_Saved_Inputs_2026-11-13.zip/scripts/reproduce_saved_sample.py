"""Read saved, labelled synthetic inputs offline; never regenerate them."""
import argparse
import hashlib
import json
import math
import sys
from datetime import date
from pathlib import Path
from zoneinfo import ZoneInfo, reset_tzpath

sys.dont_write_bytecode = True
package = Path(__file__).resolve().parents[1]
blocked_events = []


def deny_network(event, arguments):
    if event.startswith('socket.'):
        blocked_events.append(event)
        raise PermissionError('Network is disabled for saved-sample replay')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe_child(folder, name):
    path = (folder / name).resolve()
    if not path.is_relative_to(folder.resolve()):
        raise ValueError('Manifest path escapes its directory')
    return path


def run(output):
    sys.addaudithook(deny_network)
    # This local probe must fail before a socket or connection can be created.
    import socket
    try:
        probe = socket.socket()
    except PermissionError:
        pass
    else:
        probe.close()
        raise RuntimeError('Offline guard did not block the probe')
    manifest = json.loads((package / 'metadata/evidence_package_manifest.json').read_text())
    for name, expected in manifest['files'].items():
        if digest(safe_child(package, name)) != expected:
            raise ValueError('PACKAGE_HASH_MISMATCH: ' + name)
    reset_tzpath([str(package / 'vendor/zoneinfo')])
    ZoneInfo.clear_cache()
    sys.path.insert(0, str(package / 'scripts'))
    import final_day_pipeline as pipeline
    import m1_forecast as model
    from storage_policy import ensure_storage
    ensure_storage(output)
    if output.exists() or output.is_relative_to(package):
        raise ValueError('Choose a NEW output directory outside the extracted package')
    folder = package / 'samples/frozen'
    locked = json.loads((folder / 'lock_manifest.json').read_text())
    if locked['status'] != 'SYNTHETIC_SAVED_INPUTS_NOT_MARKET_DATA':
        raise ValueError('This entry point is for the labelled sample only')
    for name, expected in locked['files'].items():
        if digest(safe_child(folder, name)) != expected:
            raise ValueError('SAMPLE_HASH_MISMATCH: ' + name)
    expected = json.loads((package / 'samples/expected_result.json').read_text())
    if digest(folder / 'lock_manifest.json') != expected['input_manifest_sha256']:
        raise ValueError('Unexpected sample input version')
    prices = {d: float(value) for d, value in pipeline.daily(folder / 'SP500.csv', 'SP500').items()}
    vix = {d: float(value) for d, value in pipeline.daily(folder / 'VIXCLS.csv', 'VIXCLS').items()}
    current, rows = model.prepare(date.fromisoformat(locked['origin']), prices, vix,
                                  pipeline.calendar(folder / 'session_calendar.csv'))
    estimates = {str(w or 'expanding'): model.estimate(current, rows, w) for w in (260, 156, None)}
    matches = {}
    for name, actual in estimates.items():
        wanted = expected['estimates'][name]
        matches[name] = (actual['forecast_2dp'] == wanted['forecast_2dp']
                         and actual['n_train'] == wanted['n_train']
                         and actual['uses_vrp_sample_membership'] == wanted['uses_vrp_sample_membership']
                         and pipeline.training_hash(actual['train_origins']) == wanted['training_dates_sha256']
                         and math.isclose(actual['forecast_full_precision'], wanted['forecast_full_precision'], rel_tol=0, abs_tol=1e-10)
                         and math.isclose(actual['mu_log_comparable_horizon'], wanted['mu_log_comparable_horizon'], rel_tol=0, abs_tol=1e-14))
    if not all(matches.values()):
        raise ValueError('Saved expected result mismatch: ' + repr(matches))
    if any(digest(folder / name) != value for name, value in locked['files'].items()):
        raise ValueError('Sample inputs changed during replay')
    output.mkdir(parents=True)
    result = {'status': 'PASS_SYNTHETIC_REPLAY_NOT_FINAL_FORECAST',
              'sample_forecast_2dp': estimates['260']['forecast_2dp'],
              'matches_saved_expected_results': matches,
              'input_manifest_sha256': digest(folder / 'lock_manifest.json'),
              'estimator_sha256': digest(package / 'scripts/m1_forecast.py'),
              'python_version': sys.version.split()[0], 'site_packages_disabled': bool(sys.flags.no_site),
              'isolated_mode': bool(sys.flags.isolated), 'sample_inputs_unchanged': True,
              'network_probe_blocked': blocked_events == ['socket.__new__'],
              'ai_account_or_subscription_used': False,
              'real_forecast_record': 'FINAL_FORECAST.json; not reconstructed by invented inputs.'}
    model.save(output / 'sample_replay_result.json', result)
    model.save(output / 'sample_calculation_details.json', {
        'status': 'SYNTHETIC_ONLY_NOT_MARKET_DATA', 'current': current, 'estimates': estimates})
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    run(parser.parse_args().output.resolve())
