# Assessment 1: self-contained evidence package

The sole approved forecast is **7,606.95 index points**, S&P 500 official close
on 20 November 2026 at 16:00 EST / 21:00 UTC. Information cutoff: 13 November
2026 at 12:00 London GMT / UTC. Full record: `FINAL_FORECAST.json`.

This package supplements the published submission with saved sample inputs.
It does not change the model, forecast or approval. See `EVIDENCE_REQUIREMENTS.md`.

## Saved snapshot and restricted data

The brief permits labelled sample inputs where redistribution is restricted.
`samples/frozen/` contains a **frozen synthetic substitute**, not observed market
levels or a transformation of the private series. Its column names match the
real calculator. The notice, manifest and expected-result statuses label it.
Private real originals remain local; their URLs, receipt dates and hashes are
in `metadata/final_source_registry.json`. No credentials or real price series
are included.

**The sample reproduces the calculation on saved sample inputs, not the real
7,606.95 estimate.** Exact real-data replay needs lawful access to matching
frozen real inputs. Hashes are not data or proof of historical publication time.

## Offline reproduction: no account, AI, download or pip installation

1. Extract the single ZIP into a new directory.
2. Open a terminal there, using an existing Python 3.13 or 3.14 interpreter
   (tested: Python 3.14.6).
3. Choose a NEW output directory outside the extracted package and run:

```text
python -I -S -B scripts/reproduce_saved_sample.py --output ../saved_sample_check_01
```

On Windows, `py -3` or an installed Python's full path can replace `python`.
This uses only the standard library and a bundled, unmodified New_York timezone
file with its licence notices. `SOFTWARE_VERSIONS.json` records versions/hashes.
`-I -S` disables external site packages; `-B` disables bytecode cache writes.

The command READS saved CSVs, never regenerates them. It checks package/input
hashes, invokes the unchanged production M1 estimator, checks all three window
outputs against saved expectations and writes labelled sample results. Socket
operations are blocked; an intentional socket-creation probe tests that guard.

Expected status: `PASS_SYNTHETIC_REPLAY_NOT_FINAL_FORECAST`.
Expected **invented sample** value: `125.21`, not an alternative course forecast.
All three expected-result comparisons must be true. Outputs:
`sample_replay_result.json` and `sample_calculation_details.json`.
Changed saved inputs must cause `PACKAGE_HASH_MISMATCH` and stop.

The student's own E-only rule remains enabled locally. Public users need no
particular drive letter, just a writable output path outside the package.

## Contents

- `METHOD.md`: frozen method, assumptions and selection rules.
- `AGENT_INSTRUCTIONS.md`: sanitised agent instructions and authority limits.
- `FINAL_RUN_TRANSCRIPT.md`: redacted real-run transcript (the brief asks for a
  transcript OR screenshots, not both).
- `SAMPLE_REPLAY_TRANSCRIPT.md`: isolated saved-input test and limitations.
- `scripts/` and `independent/`: calculation, source controls and independent tests.
- `metadata/`: sources, calendars, aggregate results and validation records.
- `samples/`: saved invented inputs, notice and expected result.
- `vendor/`: required timezone file and licence notices.

`FOUNDATION_README.md` preserves broader historical research instructions and
optional dependencies; those are NOT needed for the saved-sample command.
Older package/release manifests describe their preparation snapshots. The current
ZIP inventory is `metadata/evidence_package_manifest.json`, excluding itself.
Archive creation/test success is not submission-platform receipt.
