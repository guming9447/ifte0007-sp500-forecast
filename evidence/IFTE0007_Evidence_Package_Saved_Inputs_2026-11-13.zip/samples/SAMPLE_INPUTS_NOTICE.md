# Invented sample inputs, NOT market data

The SP500 and VIXCLS numbers in `frozen/` are invented using deterministic
sine/cosine formulas recorded in `lock_manifest.json`. They are not downloaded,
scaled, anonymised or otherwise derived from any real market-price series.
Calendar dates/session times are the non-price metadata already supplied.

The frozen sample has 2,528 observations per series ending 12 November 2026.
The calendar covers the 20 November target. It exercises the same M1 mature-label,
sample-membership and rolling-window rules as the production calculation.
Expected outputs are saved once; replay never regenerates inputs or downloads.

Column names remain SP500/VIXCLS to use the original parsers unchanged. All
notices and status fields distinguish these invented inputs and their result
125.21 from the only real submission forecast in `FINAL_FORECAST.json`.
