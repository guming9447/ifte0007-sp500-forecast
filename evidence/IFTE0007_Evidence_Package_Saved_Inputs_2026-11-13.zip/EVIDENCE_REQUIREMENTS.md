# Evidence requirement crosswalk

This applies the supplied brief including its restricted-redistribution sample
exception. It does not guarantee a particular mark.

| Requirement | Included file or implementation |
|---|---|
| One ZIP | This single archive contains all items below. |
| Frozen snapshot | Saved CSVs, calendar and hashed lock manifest in `samples/frozen/`, explicitly invented substitutes; restricted originals remain private. |
| Calculation files or notebook | Unchanged `scripts/m1_forecast.py`, final pipeline and saved-input replay entry point. A notebook is an alternative, not additionally required. |
| Agent instructions | `AGENT_INSTRUCTIONS.md`. |
| Short run transcript or screenshots | `FINAL_RUN_TRANSCRIPT.md` and `SAMPLE_REPLAY_TRANSCRIPT.md`; screenshots are not additionally required. |
| README reproduction steps | Root `README.md`: one offline command reads saved inputs and checks expected output. |
| Software versions | `SOFTWARE_VERSIONS.json`, pinned optional requirements, test records and bundled timezone subset/licences. |
| Final forecast record | `FINAL_FORECAST.json`: market, unit, target, information cutoff and sole approved value. |
| No student account or live AI | Isolated execution from saved files, without login, AI API, network or pip installation. |
| Remove credentials | Only public allowlisted files; no private account configuration, tokens or chat exports. |
| Labelled sample inputs where restricted | Sample notice, manifest and output statuses make the substitution explicit. |

The sample runs the complete estimation calculation rather than multiplying a
hard-coded final drift. It does not reconstruct the private observed data or
prove historical availability. Exact real-market replay still needs the matching
lawfully held frozen originals. The actual final result and source hashes remain
recorded separately and unchanged.
