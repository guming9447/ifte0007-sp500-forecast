# Saved-sample replay: actual validation record

Prepared on 13 November 2026 as an evidence-format supplement after approval of
the real final forecast. No new market observations, fitted real parameters,
model selection or forecast changes are involved. This is not a backdated
formal-run record. The real run is separately described in FINAL_RUN_TRANSCRIPT.md.

Environment: Windows, clean Python 3.14.6 virtual environment created WITHOUT
pip. Replay used `-I -S -B`: isolated imports, no external site packages and no
bytecode-cache writes. The bundled unmodified New_York TZif file supplies timezone
rules (tzdata 2026.2 / IANA 2026b). No student account or AI service was used.

Command, from the extracted package directory:

```text
python -I -S -B scripts/reproduce_saved_sample.py --output ../saved_sample_check_01
```

Actual output summary:

```text
status: PASS_SYNTHETIC_REPLAY_NOT_FINAL_FORECAST
sample_forecast_2dp: 125.21
260 / 156 / expanding saved-result matches: true / true / true
site_packages_disabled: true
isolated_mode: true
sample_inputs_unchanged: true
network_probe_blocked: true
ai_account_or_subscription_used: false
```

The socket probe was blocked before creation/connection. A second run in a fresh
output directory gave identical result fields. Altering the final saved synthetic
SP500 value in a disposable copy caused PACKAGE_HASH_MISMATCH and a non-zero exit;
no result directory was produced. The original snapshot remained unchanged.

All six pre-existing public synthetic suites also passed in the pip-free
environment using the bundled timezone path: 7 + 19 + 46 + 36 + 15 + 35 = 158 tests.
Those tests generate their own fixtures; they are separate from the saved-input
replay above. No new Linux execution is claimed.

Machine-readable summary: metadata/saved_sample_validation.json.
The unchanged estimator SHA-256 is recorded in SOFTWARE_VERSIONS.json.
The result 125.21 is invented-data demonstration output, not a second forecast;
it does not reconstruct the real private-input forecast of 7,606.95.
